-- phpMyAdmin SQL Dump
-- version 2.11.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Erstellungszeit: 07. Januar 2008 um 20:58
-- Server Version: 5.0.45
-- PHP-Version: 5.2.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Datenbank: `tab3`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tab3_address`
--

DROP TABLE IF EXISTS `tab3_address`;
CREATE TABLE IF NOT EXISTS `tab3_address` (
  `refid` int(11) NOT NULL auto_increment,
  `id` int(11) NOT NULL default '0',
  `type` varchar(20) NOT NULL default '',
  `line1` varchar(100) default NULL,
  `line2` varchar(100) default NULL,
  `city` varchar(50) default NULL,
  `state` varchar(10) default NULL,
  `zip` varchar(20) default NULL,
  `country` varchar(3) default NULL,
  `latitude` decimal(15,12) default NULL,
  `longitude` decimal(15,12) default NULL,
  PRIMARY KEY  (`refid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Daten für Tabelle `tab3_address`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tab3_contact`
--

DROP TABLE IF EXISTS `tab3_contact`;
CREATE TABLE IF NOT EXISTS `tab3_contact` (
  `id` int(11) NOT NULL auto_increment,
  `firstname` varchar(40) NOT NULL default '',
  `lastname` varchar(80) NOT NULL default '',
  `middlename` varchar(40) default NULL,
  `namePrefix` varchar(40) NOT NULL default '',
  `nameSuffix` varchar(40) NOT NULL default '',
  `sex` enum('blank','female','male','shemale') NOT NULL default 'blank',
  `primaryAddress` int(11) default NULL,
  `nickname` varchar(40) default NULL,
  `pictureURL` varchar(255) default NULL,
  `pictureData` mediumblob,
  `notes` text,
  `lastUpdate` datetime default NULL,
  `hidden` int(1) NOT NULL default '0',
  `private` int(1) NOT NULL default '0',
  `whoAdded` int(11) default NULL,
  `lastModification` enum('imported','added','changed','deleted') NOT NULL default 'imported',
  `certExpires` date NOT NULL default '0000-00-00',
  `certLastUsed` date default NULL,
  `organizationalUnit` varchar(25) default NULL,
  `certPassword` varchar(30) default NULL,
  `certState` enum('none','new','issued','mailed','used','expired','revoked') NOT NULL default 'none',
  `whoModified` int(11) default NULL,
  `xsltDisplayType` varchar(20) default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Daten für Tabelle `tab3_contact`
--

INSERT INTO `tab3_contact` (`id`, `firstname`, `lastname`, `middlename`, `namePrefix`, `nameSuffix`, `sex`, `primaryAddress`, `nickname`, `pictureURL`, `pictureData`, `notes`, `lastUpdate`, `hidden`, `private`, `whoAdded`, `lastModification`, `certExpires`, `certLastUsed`, `organizationalUnit`, `certPassword`, `certState`, `whoModified`, `xsltDisplayType`) VALUES
(1, '', 'admin@example.com', NULL, '', '', 'blank', NULL, NULL, NULL, NULL, NULL, '2008-01-07 20:56:13', 0, 0, 1, 'added', '0000-00-00', NULL, NULL, NULL, 'none', 1, '');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tab3_dates`
--

DROP TABLE IF EXISTS `tab3_dates`;
CREATE TABLE IF NOT EXISTS `tab3_dates` (
  `id` int(11) NOT NULL,
  `type` enum('yearly','monthly','weekly','once','autoremove') NOT NULL default 'yearly',
  `value1` date default '0000-00-00',
  `value2` date default '0000-00-00',
  `label` varchar(40) NOT NULL,
  `visibility` enum('visible','hidden','admin-hidden') NOT NULL default 'visible'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `tab3_dates`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tab3_grouplist`
--

DROP TABLE IF EXISTS `tab3_grouplist`;
CREATE TABLE IF NOT EXISTS `tab3_grouplist` (
  `groupid` int(11) NOT NULL auto_increment,
  `groupname` varchar(60) default NULL,
  `logoURL` varchar(255) NOT NULL default '',
  `acronym` varchar(6) NOT NULL default '',
  PRIMARY KEY  (`groupid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Daten für Tabelle `tab3_grouplist`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tab3_groups`
--

DROP TABLE IF EXISTS `tab3_groups`;
CREATE TABLE IF NOT EXISTS `tab3_groups` (
  `id` int(11) NOT NULL default '0',
  `groupid` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`id`,`groupid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `tab3_groups`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tab3_options`
--

DROP TABLE IF EXISTS `tab3_options`;
CREATE TABLE IF NOT EXISTS `tab3_options` (
  `optID` int(11) NOT NULL auto_increment,
  `bdayInterval` int(3) NOT NULL default '21',
  `bdayDisplay` int(1) NOT NULL default '1',
  `picAlwaysDisplay` int(1) NOT NULL default '0',
  `picWidth` int(1) NOT NULL default '140',
  `picHeight` int(1) NOT NULL default '140',
  `picAllowUpload` int(1) NOT NULL default '1',
  `picCrop` int(1) NOT NULL default '0',
  `picForceWidth` int(1) NOT NULL default '0',
  `picForceHeight` int(1) NOT NULL default '0',
  `msgLogin` text,
  `msgWelcome` text,
  `countryDefault` varchar(3) default '0',
  `allowUserReg` enum('no','everyone','contactOnly','contactOnlyNoConfirm') NOT NULL default 'no',
  `eMailAdmin` int(1) NOT NULL default '0',
  `requireLogin` int(1) NOT NULL default '1',
  `language` varchar(25) default NULL,
  `limitEntries` smallint(3) NOT NULL default '0',
  `defaultGroup` varchar(60) NOT NULL default '',
  `TABversion` varchar(10) NOT NULL default '3',
  `recentlyChangedDisplay` int(1) default '0',
  `adminEmailSubject` varchar(80) default 'The Address Book Reloaded',
  `adminEmailFooter` varchar(120) default 'Best regards, the administrators of The Address Book Reloaded.',
  `administrativeLock` int(1) default '0',
  `deleteTrashMode` int(1) default '1',
  `interfaceStyle` varchar(40) default 'default',
  `autocompleteLimit` int(2) default '12',
  `recentlyChangedLimit` int(4) default '8',
  `telURI` varchar(40) NOT NULL default 'sip:$',
  `faxURI` varchar(40) NOT NULL default 'fax:$',
  PRIMARY KEY  (`optID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Daten für Tabelle `tab3_options`
--

INSERT INTO `tab3_options` (`optID`, `bdayInterval`, `bdayDisplay`, `picAlwaysDisplay`, `picWidth`, `picHeight`, `picAllowUpload`, `picCrop`, `picForceWidth`, `picForceHeight`, `msgLogin`, `msgWelcome`, `countryDefault`, `allowUserReg`, `eMailAdmin`, `requireLogin`, `language`, `limitEntries`, `defaultGroup`, `TABversion`, `recentlyChangedDisplay`, `adminEmailSubject`, `adminEmailFooter`, `administrativeLock`, `deleteTrashMode`, `interfaceStyle`, `autocompleteLimit`, `recentlyChangedLimit`, `telURI`, `faxURI`) VALUES
(1, 21, 1, 0, 140, 140, 1, 0, 0, 0, 'Please log in to access the Address Book Reloaded', '<strong>Welcome to the Address Book Reloaded</strong>', '0', 'no', 0, 1, NULL, 0, '', '3.3', 0, 'The Address Book Reloaded', 'Best regards, the administrators of The Address Book Reloaded.', 0, 1, 'default', 12, 8, 'sip:$', 'fax:$');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tab3_plugins`
--

DROP TABLE IF EXISTS `tab3_plugins`;
CREATE TABLE IF NOT EXISTS `tab3_plugins` (
  `name` varchar(50) NOT NULL default '',
  `state` enum('not installed','activated','deactivated') NOT NULL default 'not installed',
  `version` varchar(10) default NULL,
  PRIMARY KEY  (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `tab3_plugins`
--

INSERT INTO `tab3_plugins` (`name`, `state`, `version`) VALUES
('AddNewEntryMenu', 'deactivated', NULL),
('AdminCertificateAuthority', 'not installed', NULL),
('AdministrativeRequest', 'not installed', NULL),
('AdministrativeRequestMailer', 'deactivated', NULL),
('ContactChangeLogger', 'not installed', NULL),
('Export', 'deactivated', NULL),
('Import', 'deactivated', NULL),
('inTouch', 'not installed', NULL),
('Mailto', 'deactivated', NULL),
('Map', 'not installed', NULL),
('PDFbook', 'deactivated', NULL),
('Relationships', 'not installed', NULL),
('SingleSignOn', 'deactivated', NULL),
('UserChangeLogger', 'deactivated', NULL);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tab3_properties`
--

DROP TABLE IF EXISTS `tab3_properties`;
CREATE TABLE IF NOT EXISTS `tab3_properties` (
  `id` int(11) NOT NULL default '0',
  `value` text,
  `label` varchar(40) default NULL,
  `type` enum('other','phone','email','www','chat') NOT NULL default 'other',
  `visibility` enum('visible','hidden','admin-hidden') NOT NULL default 'visible',
  `refid` int(11) default NULL,
  KEY `type` (`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `tab3_properties`
--

INSERT INTO `tab3_properties` (`id`, `value`, `label`, `type`, `visibility`, `refid`) VALUES
(1, 'admin@example.com', '', 'email', 'visible', NULL);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tab3_users`
--

DROP TABLE IF EXISTS `tab3_users`;
CREATE TABLE IF NOT EXISTS `tab3_users` (
  `userid` int(11) NOT NULL auto_increment,
  `id` int(11) default NULL,
  `usertype` enum('admin','manager','user','guest','register') NOT NULL default 'register',
  `password` varchar(32) NOT NULL default '',
  `reg_email` varchar(50) NOT NULL default '',
  `confirm_hash` varchar(50) default NULL,
  `bdayInterval` int(3) default NULL,
  `bdayDisplay` int(1) default NULL,
  `useMailScript` int(1) default NULL,
  `language` varchar(25) default NULL,
  `limitEntries` smallint(3) NOT NULL default '0',
  `lastLogin` date default NULL,
  `telURI` varchar(40) default 'sip:$@example.com',
  `faxURI` varchar(40) default 'fax:$',
  `failedLogins` int(2) default '0',
  `lastRemoteIP` varchar(40) default '',
  PRIMARY KEY  (`userid`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Daten für Tabelle `tab3_users`
--

INSERT INTO `tab3_users` (`userid`, `id`, `usertype`, `password`, `reg_email`, `confirm_hash`, `bdayInterval`, `bdayDisplay`, `useMailScript`, `language`, `limitEntries`, `lastLogin`, `telURI`, `faxURI`, `failedLogins`, `lastRemoteIP`) VALUES
(1, 1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'admin@example.com', NULL, NULL, NULL, NULL, NULL, 0, '2008-01-07', 'sip:$@example.com', 'fax:$', 0, '127.0.0.1');
